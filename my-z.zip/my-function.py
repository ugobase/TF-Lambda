def ugo(event,context):
    print("I am Ugob")